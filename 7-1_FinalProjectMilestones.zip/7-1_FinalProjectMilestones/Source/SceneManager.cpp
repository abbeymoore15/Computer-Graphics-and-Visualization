///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the texture collection.
	m_loadedTextures = 0;

	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "";
		m_textureIDs[i].ID = 0;
	}
}
SceneManager::~SceneManager()
{
	m_pShaderManager = nullptr;

	delete m_basicMeshes;
	m_basicMeshes = nullptr;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


void SceneManager::LoadSceneTextures()
{
	// Load textures used by the car and track.
	CreateGLTexture("textures/blue_paint.jpg", "bluePaint");
	CreateGLTexture("textures/rubber.jpg", "rubber");
	CreateGLTexture("textures/metal.jpg", "metal");
	CreateGLTexture("textures/asphalt.jpg", "asphalt");
	CreateGLTexture("textures/redPaint.jpg", "redPaint");

	// Bind the loaded textures to OpenGL texture slots.
	BindGLTextures();
}
void SceneManager::DefineObjectMaterials()
{
	// Asphalt
	OBJECT_MATERIAL asphaltMaterial;
	asphaltMaterial.diffuseColor = glm::vec3(0.65f, 0.65f, 0.65f);
	asphaltMaterial.specularColor = glm::vec3(0.18f, 0.18f, 0.18f);
	asphaltMaterial.shininess = 8.0f;
	asphaltMaterial.tag = "asphaltMaterial";
	m_objectMaterials.push_back(asphaltMaterial);

	// Car body
	OBJECT_MATERIAL paintMaterial;
	paintMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	paintMaterial.specularColor = glm::vec3(0.90f, 0.90f, 0.90f);
	paintMaterial.shininess = 64.0f;
	paintMaterial.tag = "paintMaterial";
	m_objectMaterials.push_back(paintMaterial);

	// Tires
	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.diffuseColor = glm::vec3(0.65f, 0.65f, 0.65f);
	rubberMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	rubberMaterial.shininess = 4.0f;
	rubberMaterial.tag = "rubberMaterial";
	m_objectMaterials.push_back(rubberMaterial);

	// Rims
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	metalMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	metalMaterial.shininess = 96.0f;
	metalMaterial.tag = "metalMaterial";
	m_objectMaterials.push_back(metalMaterial);

	// Windshield and headlights
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	glassMaterial.specularColor = glm::vec3(0.95f, 0.95f, 0.95f);
	glassMaterial.shininess = 80.0f;
	glassMaterial.tag = "glassMaterial";
	m_objectMaterials.push_back(glassMaterial);
}

void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Warm sun
	m_pShaderManager->setVec3Value(
		"directionalLight.direction",
		glm::vec3(-0.4f, -1.0f, -0.3f));

	m_pShaderManager->setVec3Value(
		"directionalLight.ambient",
		glm::vec3(0.28f, 0.30f, 0.34f));

	m_pShaderManager->setVec3Value(
		"directionalLight.diffuse",
		glm::vec3(1.0f, 0.90f, 0.72f));

	m_pShaderManager->setVec3Value(
		"directionalLight.specular",
		glm::vec3(1.0f, 0.95f, 0.85f));

	m_pShaderManager->setBoolValue(
		"directionalLight.bActive", true);

	// A smidge of pink
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		glm::vec3(5.0f, 4.0f, -4.0f));

	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		glm::vec3(0.015f, 0.005f, 0.01f));

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		glm::vec3(0.18f, 0.04f, 0.08f));

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		glm::vec3(0.28f, 0.08f, 0.14f));

	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive", true);

	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive", false);

	m_pShaderManager->setBoolValue(
		"spotLight.bActive", false);
}

void SceneManager::PrepareScene()
{
	// Load each basic mesh once before rendering the scene.
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadPyramid4Mesh();
}

void SceneManager::RenderScene()
{
	// Transformation variables used for each basic shape.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Grey plane representing the track beneath the car
	scaleXYZ = glm::vec3(20.0f, 1.0f, 15.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Tile the asphalt texture
	SetShaderMaterial("asphaltMaterial");
	SetShaderTexture("asphalt");
	SetTextureUVScale(8.0f, 8.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Main blue car body
	scaleXYZ = glm::vec3(7.5f, 1.4f, 2.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 1.65f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("paintMaterial");
	SetShaderTexture("bluePaint");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Roof
	scaleXYZ = glm::vec3(3.2f, 1.35f, 2.4f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.0f, 2.85f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("paintMaterial");
	SetShaderTexture("bluePaint");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Windshield
	scaleXYZ = glm::vec3(0.18f, 1.05f, 2.25f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -18.0f;
	positionXYZ = glm::vec3(-0.72f, 2.85f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glassMaterial");
	SetShaderColor(0.08f, 0.16f, 0.22f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
	
	//Hood scoop
	scaleXYZ = glm::vec3(2.3f, 0.55f, 1.35f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.0f, 2.45f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("paintMaterial");
	SetShaderTexture("bluePaint");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Front bumper
	scaleXYZ = glm::vec3(0.60f, 0.60f, 3.1f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.0f, 1.15f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("paintMaterial");
	SetShaderTexture("bluePaint");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Headlight
	scaleXYZ = glm::vec3(0.35f, 0.48f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.17f, 1.82f, 0.75f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glassMaterial");
	SetShaderColor(0.80f, 0.90f, 1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Rear spoiler
	scaleXYZ = glm::vec3(1.3f, 0.18f, 3.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.45f, 2.62f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("paintMaterial");
	SetShaderTexture("bluePaint");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Front driver side tire
	scaleXYZ = glm::vec3(0.90f, 0.38f, 0.90f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.55f, 0.85f, 1.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("rubberMaterial");
	SetShaderTexture("rubber");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Rear driver side tire
	scaleXYZ = glm::vec3(1.05f, 0.42f, 1.05f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.65f, 0.95f, 1.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("rubberMaterial");
	SetShaderTexture("rubber");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Front passenger tire
	scaleXYZ = glm::vec3(0.90f, 0.38f, 0.90f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.55f, 0.85f, -1.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("rubberMaterial");
	SetShaderTexture("rubber");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Rear passenger tire
	scaleXYZ = glm::vec3(1.05f, 0.42f, 1.05f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.65f, 0.95f, -1.48f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("rubberMaterial");
	SetShaderTexture("rubber");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Front rim
	scaleXYZ = glm::vec3(0.58f, 0.18f, 0.58f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.55f, 0.85f, 1.95f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Rear rim
	scaleXYZ = glm::vec3(0.68f, 0.18f, 0.68f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.65f, 0.95f, 1.97f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metalMaterial");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	auto drawPart = [this](
		const glm::vec3& scale,
		const glm::vec3& position,
		float rotateX,
		float rotateY,
		float rotateZ,
		const char* material,
		const char* texture,
		const glm::vec4& color)
		{
			SetTransformations(
				scale,
				rotateX,
				rotateY,
				rotateZ,
				position);

			SetShaderMaterial(material);

			if (texture != nullptr)
			{
				SetShaderTexture(texture);
				SetTextureUVScale(1.0f, 1.0f);
			}
			else
			{
				SetShaderColor(color.r, color.g, color.b, color.a);
			}
			if (texture != nullptr &&
				(std::string(texture) == "rubber" ||
					std::string(texture) == "metal"))
			{
				m_basicMeshes->DrawCylinderMesh();
			}
			else
			{
				m_basicMeshes->DrawBoxMesh();
			}
		};

	// Place the red car beside the blue car.
	const glm::vec3 redOffset(0.0f, 0.0f, -6.0f);

	// Red car body, roof, hood scoop, bumper, and spoiler.
	drawPart(glm::vec3(7.5f, 1.4f, 2.8f),
		glm::vec3(0.0f, 1.65f, 0.0f) + redOffset,
		0.0f, 0.0f, 0.0f, "paintMaterial", "redPaint", glm::vec4(1.0f));

	drawPart(glm::vec3(3.2f, 1.35f, 2.4f),
		glm::vec3(1.0f, 2.85f, 0.0f) + redOffset,
		0.0f, 0.0f, 0.0f, "paintMaterial", "redPaint", glm::vec4(1.0f));

	drawPart(glm::vec3(2.3f, 0.55f, 1.35f),
		glm::vec3(-2.0f, 2.45f, 0.0f) + redOffset,
		0.0f, 0.0f, 0.0f, "paintMaterial", "redPaint", glm::vec4(1.0f));

	drawPart(glm::vec3(0.60f, 0.60f, 3.1f),
		glm::vec3(-4.0f, 1.15f, 0.0f) + redOffset,
		0.0f, 0.0f, 0.0f, "paintMaterial", "redPaint", glm::vec4(1.0f));

	drawPart(glm::vec3(1.3f, 0.18f, 3.2f),
		glm::vec3(3.45f, 2.62f, 0.0f) + redOffset,
		0.0f, 0.0f, 0.0f, "paintMaterial", "redPaint", glm::vec4(1.0f));

	// Windshield
	drawPart(glm::vec3(0.18f, 1.05f, 2.25f),
		glm::vec3(-0.72f, 2.85f, 0.0f) + redOffset,
		0.0f, 0.0f, -18.0f, "glassMaterial", nullptr,
		glm::vec4(0.08f, 0.16f, 0.22f, 1.0f));

	// Tires and rims
	const float wheelX[4] = { -2.55f, 2.65f, -2.55f, 2.65f };
	const float wheelY[4] = { 0.85f, 0.95f, 0.85f, 0.95f };
	const float wheelZ[4] = { 1.48f, 1.48f, -1.48f, -1.48f };
	const float tireSize[4] = { 0.90f, 1.05f, 0.90f, 1.05f };

	for (int i = 0; i < 4; i++)
	{
		drawPart(glm::vec3(tireSize[i], 0.40f, tireSize[i]),
			glm::vec3(wheelX[i], wheelY[i], wheelZ[i]) + redOffset,
			90.0f, 0.0f, 0.0f, "rubberMaterial", "rubber", glm::vec4(1.0f));
	}

	// Rims
	drawPart(glm::vec3(0.58f, 0.18f, 0.58f),
		glm::vec3(-2.55f, 0.85f, 1.95f) + redOffset,
		90.0f, 0.0f, 0.0f, "metalMaterial", "metal", glm::vec4(1.0f));

	drawPart(glm::vec3(0.68f, 0.18f, 0.68f),
		glm::vec3(2.65f, 0.95f, 1.97f) + redOffset,
		90.0f, 0.0f, 0.0f, "metalMaterial", "metal", glm::vec4(1.0f));

	// Racing tree
	drawPart(glm::vec3(0.16f, 5.5f, 0.16f),
		glm::vec3(2.0f, 2.75f, -1.8f),
		0.0f, 0.0f, 0.0f, "metalMaterial", nullptr,
		glm::vec4(0.12f, 0.12f, 0.12f, 1.0f));

	// Blue center panel
	drawPart(glm::vec3(0.55f, 3.1f, 0.28f),
		glm::vec3(2.0f, 4.1f, -1.8f),
		0.0f, 0.0f, 0.0f, "metalMaterial", nullptr,
		glm::vec4(0.05f, 0.20f, 0.55f, 1.0f));

	// Lights
	drawPart(glm::vec3(0.28f, 0.12f, 0.28f),
		glm::vec3(2.0f, 5.1f, -1.58f),
		90.0f, 0.0f, 0.0f, "glassMaterial", nullptr,
		glm::vec4(1.0f, 0.05f, 0.02f, 1.0f));

	drawPart(glm::vec3(0.28f, 0.12f, 0.28f),
		glm::vec3(2.0f, 4.5f, -1.58f),
		90.0f, 0.0f, 0.0f, "glassMaterial", nullptr,
		glm::vec4(1.0f, 0.05f, 0.02f, 1.0f));

	drawPart(glm::vec3(0.28f, 0.12f, 0.28f),
		glm::vec3(2.0f, 3.9f, -1.58f),
		90.0f, 0.0f, 0.0f, "glassMaterial", nullptr,
		glm::vec4(1.0f, 0.65f, 0.02f, 1.0f));

	drawPart(glm::vec3(0.28f, 0.12f, 0.28f),
		glm::vec3(2.0f, 3.3f, -1.58f),
		90.0f, 0.0f, 0.0f, "glassMaterial", nullptr,
		glm::vec4(0.02f, 0.8f, 0.08f, 1.0f));

	// Tent
	for (int i = 0; i < 4; i++)
	{
		float tentX = (i < 2) ? -2.0f : 2.0f;
		float tentZ = (i % 2 == 0) ? -14.5f : -10.5f;

		drawPart(glm::vec3(0.10f, 2.7f, 0.10f),
			glm::vec3(tentX, 1.75f, tentZ),
			0.0f, 0.0f, 0.0f, "metalMaterial", nullptr,
			glm::vec4(0.75f, 0.75f, 0.75f, 1.0f));
	}

	// Tent roof
	scaleXYZ = glm::vec3(5.8f, 2.1f, 5.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 3.5f, -12.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glassMaterial");
	SetShaderColor(0.88f, 0.88f, 0.84f, 1.0f);
	m_basicMeshes->DrawPyramid4Mesh();
}